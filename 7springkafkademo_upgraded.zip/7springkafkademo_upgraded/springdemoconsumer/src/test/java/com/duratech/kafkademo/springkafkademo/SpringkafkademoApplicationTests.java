package com.duratech.kafkademo.springkafkademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringkafkademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
