https://medium.com/maestral-solutions/spring-boot-implementation-for-apache-kafka-with-kafka-tool-cc22995490f4
