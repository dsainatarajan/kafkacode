package com.kafkatraining.springexample.kafkaadvanced;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaadvancedApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaadvancedApplication.class, args);
	}

}
